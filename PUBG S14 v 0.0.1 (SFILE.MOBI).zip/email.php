<?php  

//----------Your Email-----------\\

$result = "youremail@gmail.com";




//  IIIIIIIIIII DDDDDDDDDDDDDDDDDDD     NNNNNNNNNN        NNNNNNNNNN
//  II:::::::II DDD:::::DDDDD:::::::D   NN::::::::N       NN::::::NN
//    I:::::I     D:::::D    D:::::::D    N::::::::N        N::::N
//    I:::::I     D:::::D     D:::::::D   N::::::::::N      N::::N
//    I:::::I     D:::::D      D:::::::D  N::::::::::::N    N::::N
//    =======     =======      =========  ======  ========= ======
//                 Author :"Nafis WA"
//    _______     _______      _________  ________  _______________
//    I:::::I     D:::::D      D:::::::D  N:::::N    N::::::NN:::N
//    I:::::I     D:::::D     D:::::::D   N:::::N      N:::::::::N
//    I:::::I     D:::::D    D:::::::D    N:::::N        N:::::::N
//  II:::::::II DD::::::DDDDDD::::::D   NN:::::::NN        N:::::N
//  IIIIIIIIIII DDDDDDDDDDDDDDDDDDDD    NNNNNNNNNNN         NNNNNN
?>
